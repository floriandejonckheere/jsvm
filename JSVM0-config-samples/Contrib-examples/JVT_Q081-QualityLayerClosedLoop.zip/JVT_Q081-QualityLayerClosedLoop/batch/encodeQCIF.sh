#!/bin/sh

# (1:SEQ) (2:MaxRate)
# ===================

./bin/H264AVCEncoderLibTestStatic -pf cfg/$1./QCIF.cfg -numl 1 -anafgs 0  1 fgs/$1Q.dat -mfile 0 2 mot/$1Q.mot 
./bin/H264AVCEncoderLibTestStatic -pf cfg/$1./QCIF.cfg -numl 1 -encfgs 0 $2 fgs/$1Q.dat -mfile 0 2 mot/$1Q.mot

