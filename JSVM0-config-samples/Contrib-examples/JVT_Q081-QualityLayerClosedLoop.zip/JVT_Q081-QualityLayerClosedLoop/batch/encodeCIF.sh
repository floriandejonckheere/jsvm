#!/bin/sh

# (1:SEQ) (2:MaxRate)
# ===================

./bin/H264AVCEncoderLibTestStatic -pf cfg/$1./CIF.cfg -numl 1 -anafgs 0  1 fgs/$1C.dat -mfile 0 2 mot/$1C.mot 
./bin/H264AVCEncoderLibTestStatic -pf cfg/$1./CIF.cfg -numl 1 -encfgs 0 $2 fgs/$1C.dat -mfile 0 2 mot/$1C.mot

