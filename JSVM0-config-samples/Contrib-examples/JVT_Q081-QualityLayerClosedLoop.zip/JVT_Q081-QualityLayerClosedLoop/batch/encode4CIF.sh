#!/bin/sh

# (1:SEQ) (2:MaxRate)
# ===================

./bin/H264AVCEncoderLibTestStatic -pf cfg/$1./4CIF.cfg -numl 1 -anafgs 0  1 fgs/$14.dat -mfile 0 2 mot/$14.mot 
./bin/H264AVCEncoderLibTestStatic -pf cfg/$1./4CIF.cfg -numl 1 -encfgs 0 $2 fgs/$14.dat -mfile 0 2 mot/$14.mot

